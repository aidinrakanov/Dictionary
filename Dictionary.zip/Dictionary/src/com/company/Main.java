package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Map<String, String[]> dictionary = new HashMap<>();
        Map<String, String[]> bigDic = new HashMap<>();

        dictionary.put("bolshoi", new String[]{"ogromniy", "gigantskiy", "gromadniy", "zdoroviy"});

        dictionary.put("persona", new String[]{"individ", "chelovek", "lichnost"});

        dictionary.put("kot", new String[]{"koshka", "kote", "kisa", "koshak"});

        dictionary.put("pes", new String[]{"sobaka", "psina", "shenok", "shaurma"});


        Set<String> keys = dictionary.keySet();
        Iterator iter = keys.iterator();
        while (iter.hasNext()) {
            String key = iter.next().toString();
            String[] values = dictionary.get(key);
            bigDic.put(key, values);
            for (int i = 0; i < values.length; i++) {
                String bkey = values[i];
                ArrayList<String> strArr = new ArrayList<>(values.length);
                strArr.addAll(Arrays.asList(values));
                strArr.remove(bkey);
                strArr.add(key);
            }
        }

        System.out.println("vvedite slovo : ");

        Scanner s = new Scanner(System.in);
        String sentences = s.nextLine();
        String[] words = sentences.split(" ");
        Random r = new Random();

        for (int i = 0; i < words.length; i++) {
            String[] synonym = dictionary.get(words[i]);
            if (synonym != null) {
                int random = r.nextInt(synonym.length);

                System.out.println(synonym[random] + " ");

            } else {
                System.out.println("takogo slovo net");
            }
        }
    }
}